CREATE VIEW ROW_DATA_v AS (
SELECT
	o.order_id,
	o.order_date,
	YEAR(o.order_date) as Order_Year,
	MONTH(o.order_date) as Order_Month,
	DAY(o.order_date) as Order_Day,
	st.store_name,
	c.customer_id,
	c.first_name + ' ' + c.last_name as Customer_Name,
	c.street as Customer_Street,
	c.city as Customer_City,
	c.state as Customer_State,
	b.brand_name,
	cat.category_name,
	p.product_name,
	p.list_price,
	SUM(oi.quantity) as Quantity_Sold,
	SUM(oi.list_price * oi.quantity) as Gross_Sales,
	SUM(oi.list_price * oi.quantity * oi.discount) as Discount_Amount,
	SUM(oi.list_price * oi.quantity * (1 - oi.discount)) as Net_Sales,
	CASE 
		WHEN o.order_status = 1 THEN 'Pending'
		WHEN o.order_status = 2 THEN 'Processing'
		WHEN o.order_status = 3 THEN 'Rejected'
		WHEN o.order_status = 4 THEN 'Completed'
	END AS order_status,
	-- Order status: 1 = Pending; 2 = Processing; 3 = Rejected; 4 = Completed
	s.first_name + ' ' + s.last_name as Staff_Name
FROM sales.orders o
LEFT JOIN sales.order_items oi
ON o.order_id = oi.order_id
LEFT JOIN sales.staffs s
ON o.staff_id = s.staff_id
LEFT JOIN sales.stores st
ON o.store_id = st.store_id
LEFT JOIN sales.customers c 
ON o.customer_id = c.customer_id
LEFT JOIN production.products p 
ON oi.product_id = p.product_id
LEFT JOIN production.categories cat
ON p.category_id = cat.category_id
LEFT JOIN production.brands b
ON p.brand_id = b.brand_id
GROUP BY 
	o.order_id,
	s.first_name + ' ' + s.last_name,
	st.store_name,
	o.order_date,
	o.order_status,
	c.customer_id,
	c.first_name + ' ' + c.last_name,
	c.street,
	c.city,
	c.state,
	p.product_name,
	p.list_price,
	cat.category_name,
	b.brand_name
);
